#!/bin/bash
echo "[+] Authenticating Instagram API..."
sleep 0.3
for i in {1..35}; do
 echo "[INSTAGRAM] pulling DM_ | story_frame_ | hash:31265"
 sleep 0.09
done
echo "[+] Followers mapped"
echo "[+] DMs archived"
echo "[+] Stories mirrored"
