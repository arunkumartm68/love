#!/bin/bash
echo "[+] Accessing phone kernel..."
sleep 0.3
for i in {1..45}; do
 echo "[PHONE] extracting contact_ | calllog_ | sms_block_"
 sleep 0.07
done
echo "[+] Contacts dumped"
echo "[+] Call logs parsed"
echo "[+] SMS recovered"
