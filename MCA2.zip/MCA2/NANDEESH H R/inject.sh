#!/bin/bash
echo "Uploading payload..."; sleep 1; echo "Tunnel secured"
