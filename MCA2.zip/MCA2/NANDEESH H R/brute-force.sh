#!/bin/bash
echo "Initializing brute engine..."; for i in {1..20}; do echo "Trying packet $i"; sleep 0.15; done; echo "Handshake retry"
