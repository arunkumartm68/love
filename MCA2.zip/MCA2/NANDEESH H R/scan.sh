#!/bin/bash
echo "Scanning ports..."; for p in {8000..8010}; do echo "Port $p open"; sleep 0.1; done
